# RocketMQ-HBase

## Overview

This project provides connectors between RocketMQ and HBase. 
The [HBase sink](rocketmq-hbase-sink) replicates HBase tables to RocketMQ topics, and 
the [HBase source](rocketmq-hbase-source) replicates RocketMQ topics to HBase tables.

