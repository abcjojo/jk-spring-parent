# rocketmq-logstash-integration

This project provides logstash input and output plugins of Apache RocketMQ. 
Please refer corresponding sub-directories for more details.

